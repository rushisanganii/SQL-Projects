-- Q10. The total number of case of confirmed, deaths, recovered each month

SELECT 
    EXTRACT(MONTH FROM Date) AS month,
    SUM(Confirmed) AS total_confirmed,
    SUM(Deaths) AS total_deaths,
    SUM(Recovered) AS total_recovered
FROM 
    [corona_virus_dataset].[dbo].[Corona Virus Dataset]
GROUP BY 
    EXTRACT(MONTH FROM Date)
ORDER BY 
    EXTRACT(MONTH FROM Date);
