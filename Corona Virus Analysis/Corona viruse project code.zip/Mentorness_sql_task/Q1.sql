-- Q1. Write a code to check NULL values

SELECT * FROM corona_virus_dataset
WHERE 'Province' IS NULL;
SELECT * FROM corona_virus_dataset
WHERE 'Country/Region' IS NULL;
SELECT * FROM corona_virus_dataset
WHERE 'Latitude' IS NULL;
SELECT * FROM corona_virus_dataset
WHERE 'Longitude' IS NULL;
SELECT * FROM corona_virus_dataset
WHERE 'Date' IS NULL;
SELECT * FROM corona_virus_dataset
WHERE 'Confirmed' IS NULL;
SELECT * FROM corona_virus_dataset
WHERE 'Deaths' IS NULL;
SELECT * FROM corona_virus_dataset
WHERE 'Recovered' IS NULL;

