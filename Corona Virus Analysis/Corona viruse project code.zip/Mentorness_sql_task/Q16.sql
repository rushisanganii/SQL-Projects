-- Q16. Find top 5 countries having highest recovered case

SELECT 
    'Country Region',
    SUM(Recovered) AS total_recovered_cases
FROM 
    [corona_virus_dataset].[dbo].[Corona Virus Dataset]
GROUP BY 
    'Country Region'
ORDER BY 
    total_recovered_cases DESC
LIMIT 5;
