-- Q11. Check how corona virus spread out with respect to confirmed case
--      (Eg.: total confirmed cases, their average, variance & STDEV )

-- Calculate total confirmed cases
SELECT SUM(Confirmed) AS total_confirmed_cases
FROM [corona_virus_dataset].[dbo].[Corona Virus Dataset];

-- Calculate average confirmed cases
SELECT AVG(Confirmed) AS average_confirmed_cases
FROM [corona_virus_dataset].[dbo].[Corona Virus Dataset];

-- Calculate variance of confirmed cases
SELECT VARIANCE(Confirmed) AS variance_confirmed_cases
FROM [corona_virus_dataset].[dbo].[Corona Virus Dataset];

-- Calculate standard deviation of confirmed cases
SELECT STDDEV(Confirmed) AS stdev_confirmed_cases
FROM [corona_virus_dataset].[dbo].[Corona Virus Dataset];


