-- Q15. Find Country having lowest number of the death case

SELECT 
    'Country Region',
    Confirmed
    
FROM 
    [corona_virus_dataset].[dbo].[Corona Virus Dataset]
WHERE 
    Confirmed = (SELECT min(Confirmed) FROM [corona_virus_dataset].[dbo].[Corona Virus Dataset]);

