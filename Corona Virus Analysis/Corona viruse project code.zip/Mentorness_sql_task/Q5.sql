-- Q5. Number of month present in dataset
SELECT COUNT(DISTINCT MONTH(CONVERT(DATE, Date, 105))) AS num_months
FROM [corona_virus_dataset].[dbo].[Corona Virus Dataset];


