-- Q8. Find minimum values for confirmed, deaths, recovered per year


SELECT 
    EXTRACT(MONTH FROM Date) AS month,
    min(Confirmed) AS minimum_confirmed,
    min(Deaths) AS minimum_deaths,
    min(Recovered) AS minimum_recovered
FROM 
    [corona_virus_dataset].[dbo].[Corona Virus Dataset]
GROUP BY 
    EXTRACT(MONTH FROM Date);
    
    
    