-- Q6. Find monthly average for confirmed, deaths, recovered

SELECT 
    EXTRACT(MONTH FROM Date) AS month,
    AVG(Confirmed) AS avg_confirmed,
    AVG(Deaths) AS avg_deaths,
    AVG(Recovered) AS avg_recovered
FROM
    [corona_virus_dataset].[dbo].[Corona Virus Dataset]
GROUP BY EXTRACT(MONTH FROM Date);
