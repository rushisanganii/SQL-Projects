-- Q12. Check how corona virus spread out with respect to death case per month
--      (Eg.: total confirmed cases, their average, variance & STDEV )

-- Calculate total deaths cases
SELECT 
    SUM(Deaths) AS total_deaths_cases
FROM 
    [corona_virus_dataset].[dbo].[Corona Virus Dataset];

-- Calculate average deaths cases
SELECT 
    AVG(Deaths) AS average_deaths_cases
FROM 
    [corona_virus_dataset].[dbo].[Corona Virus Dataset];

-- Calculate variance of deaths cases
SELECT 
    VARIANCE(Deaths) AS variance_Deaths_cases
FROM 
    [corona_virus_dataset].[dbo].[Corona Virus Dataset];

-- Calculate standard deviation of deaths cases
SELECT 
    STDDEV(Confirmed) AS stdev_confirmed_cases
FROM 
    [corona_virus_dataset].[dbo].[Corona Virus Dataset];
