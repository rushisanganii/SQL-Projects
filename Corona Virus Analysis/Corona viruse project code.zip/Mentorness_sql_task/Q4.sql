-- Q4. Check what is start_date and end_date

SELECT 
    MIN(Date) AS start_date, MAX(Date) AS end_date
FROM
    [corona_virus_dataset].[dbo].[Corona Virus Dataset]